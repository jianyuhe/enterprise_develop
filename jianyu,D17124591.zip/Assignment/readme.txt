configuration and deployment information��
Bootstrap, jquery, mysql, rest api, express, node js, java script, session